# Real-Estate-Analytic-Website
- Collection of data using Web Scraping, which involved extracting information from website 99acres.com and preprocessed the data involved cleaning, transforming, and organizing the data in a way that makes it suitable for analysis.
- Performed Feature Engineering and utilized EDA to analyse correlation of features by univariate and multivariate.
- Analyzed performance of Random Forest, Decision Tree, SVM models and the insights gained from the analysis
were used to create a website using a tool called Streamlit and Deployed on AWS.
